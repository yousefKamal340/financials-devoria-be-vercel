const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://yousefKamaldb:yoyo1075@cluster0.qje8a.mongodb.net/financial-dashboard?retryWrites=true&w=majority';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  role: { type: String, enum: ['admin', 'manager', 'employee'], default: 'employee' },
  avatar: String,
  passwordHash: { type: String, required: true },
  lastLogin: Date,
  createdAt: { type: Date, default: Date.now }
});
const User = mongoose.model('User', userSchema);

// Employee Schema
const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  position: { type: String, required: true },
  department: { type: String, required: true },
  salary: { type: Number, required: true },
  status: { type: String, default: 'active' },
  hireDate: { type: Date, default: Date.now },
  type: { type: String, enum: ['co-founder', 'employee'], default: 'employee' },
  equity: { type: Number, default: 0 }, // Co-founder specific
  vestingSchedule: String, // Co-founder specific
  benefits: [String], // Employee specific
  performanceReview: String // Employee specific
});
const Employee = mongoose.model('Employee', employeeSchema);

// BusinessExpense Schema
const expenseSchema = new mongoose.Schema({
  category: { type: String, required: true },
  amount: { type: Number, required: true },
  description: String,
  date: { type: Date, default: Date.now },
  type: String
});
const BusinessExpense = mongoose.model('BusinessExpense', expenseSchema);

// BusinessRevenue Schema
const revenueSchema = new mongoose.Schema({
  source: { type: String, required: true },
  amount: { type: Number, required: true },
  description: String,
  date: { type: Date, default: Date.now },
  type: String
});
const BusinessRevenue = mongoose.model('BusinessRevenue', revenueSchema);

// Department Schema
const departmentSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  budget: { type: Number, default: 0 },
  spent: { type: Number, default: 0 },
  employees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Employee' }]
});
const Department = mongoose.model('Department', departmentSchema);

// FinancialSummary Schema (singleton)
const financialSummarySchema = new mongoose.Schema({
  totalRevenue: { type: Number, default: 0 },
  totalExpenses: { type: Number, default: 0 },
  netProfit: { type: Number, default: 0 },
  employeeCount: { type: Number, default: 0 },
  coFounderCount: { type: Number, default: 0 },
  lastUpdated: { type: Date, default: Date.now }
});
const FinancialSummary = mongoose.model('FinancialSummary', financialSummarySchema);

// API Routes
// Users
app.post('/api/users', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json({ success: true, data: { insertedId: user._id } });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/users/email/:email', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.params.email });
    res.json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: user });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/users/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Employees
app.post('/api/employees', async (req, res) => {
  try {
    const employee = new Employee(req.body);
    await employee.save();
    res.status(201).json({ success: true, data: { insertedId: employee._id } });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json({ success: true, data: employees });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/employees/:id', async (req, res) => {
  try {
    const employee = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/employees/:id', async (req, res) => {
  try {
    await Employee.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Expenses
app.post('/api/expenses', async (req, res) => {
  try {
    const expense = new BusinessExpense(req.body);
    await expense.save();
    res.status(201).json({ success: true, data: { insertedId: expense._id } });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/expenses', async (req, res) => {
  try {
    const expenses = await BusinessExpense.find();
    res.json({ success: true, data: expenses });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/expenses/:id', async (req, res) => {
  try {
    const expense = await BusinessExpense.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: expense });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/expenses/:id', async (req, res) => {
  try {
    await BusinessExpense.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Revenues
app.post('/api/revenues', async (req, res) => {
  try {
    const revenue = new BusinessRevenue(req.body);
    await revenue.save();
    res.status(201).json({ success: true, data: { insertedId: revenue._id } });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/revenues', async (req, res) => {
  try {
    const revenues = await BusinessRevenue.find();
    res.json({ success: true, data: revenues });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/revenues/:id', async (req, res) => {
  try {
    const revenue = await BusinessRevenue.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: revenue });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/revenues/:id', async (req, res) => {
  try {
    await BusinessRevenue.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Departments
app.post('/api/departments', async (req, res) => {
  try {
    const department = new Department(req.body);
    await department.save();
    res.status(201).json({ success: true, data: { insertedId: department._id } });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get('/api/departments', async (req, res) => {
  try {
    const departments = await Department.find();
    res.json({ success: true, data: departments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/departments/:id', async (req, res) => {
  try {
    const department = await Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: department });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.delete('/api/departments/:id', async (req, res) => {
  try {
    await Department.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Financial Summary
app.get('/api/financial-summary', async (req, res) => {
  try {
    let summary = await FinancialSummary.findOne();
    if (!summary) {
      summary = new FinancialSummary();
      await summary.save();
    }
    res.json({ success: true, data: summary });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/financial-summary', async (req, res) => {
  try {
    let summary = await FinancialSummary.findOne();
    if (!summary) {
      summary = new FinancialSummary(req.body);
    } else {
      Object.assign(summary, req.body);
    }
    await summary.save();
    res.json({ success: true, data: summary });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'API is running!' });
});

// Export for Vercel
module.exports = app;
